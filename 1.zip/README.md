# FishDirect frontend

Minimal Expo SDK 58 and TypeScript workspace using Expo Router. Only placeholder
screens are implemented. No backend calls, authentication, or business features.

## Development on Windows

Use Node.js 22.13+ in the 22 LTS line (this setup was created with 22.15.0) or
another version allowed by `package.json`.

```powershell
npm ci
npx expo start --web
```

Open the printed localhost URL in Chrome. Metro provides Fast Refresh during
development. No Android Studio, SDK, emulator, or native build is required.

## Checks

```powershell
npm run typecheck
npm run lint
npm run format:check
npx expo install --check
```

Use `npm run format` to apply formatting and `npx expo start --web --clear` if
Metro's cache needs resetting.

## Organization

- `src/app`: file-based routes; `_layout.tsx` owns shared navigation.
- `src/components`: shared components; `ui` holds basic building blocks.
- `src/constants`: centralized colors and layout tokens.
- `src/data`: local mock content.
- `src/types`: shared domain types.
- `src/services/api.ts`: future Laravel integration boundary; no network code.
- `assets/images`, `assets/icons`, `assets/fonts`: future project assets.

The `@/` alias resolves to `src/`. Keep components and other non-route modules
outside `src/app`. The generated root asset files remain for Expo app metadata.
Expo supplies its default Babel and Metro configuration; custom files are not
needed. `.expo/`, `dist/`, and `node_modules/` are generated and ignored by Git.

All six routes are intentionally public placeholders: `/`, `/login`, `/register`,
`/home`, `/profile`, and `/settings`. Future Laravel integration should be added
behind the service boundary, independently of presentation components.
