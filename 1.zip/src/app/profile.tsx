import { PlaceholderScreen } from '@/components/PlaceholderScreen';

export default function ProfileScreen() {
  return <PlaceholderScreen title="Profile" description="Future profile screen." />;
}
