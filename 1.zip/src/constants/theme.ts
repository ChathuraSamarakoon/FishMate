import { colors } from './colors';

export const theme = {
  colors,
  spacing: { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 },
  radius: { sm: 8, md: 16 },
  contentWidth: 720,
} as const;
